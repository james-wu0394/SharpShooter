using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.Drawing;



namespace SharpShooter_ChrisLotton
{
    public partial class MainForm : Form
    {

        public static Player player1;
        public static List<Soldier> enemyList;
        public static List<Bullet> bulletList;
        public static List<Wall> wallList;
        public static List<Explosion> explosionList;

        
        Graphics windowsGraphics;
        Graphics onScreenGraphics;
        Bitmap screen;

        public Picture gameOverScreen;
        public Picture victoryScreen;

        public MainForm()
        {
            InitializeComponent();

            windowsGraphics = this.CreateGraphics();
            screen = new Bitmap(this.Width, this.Height);
            onScreenGraphics = Graphics.FromImage(screen);

            // Set our DrawGame method to be called when the window repaints
            this.Paint += new PaintEventHandler(DrawGame);

            Init();
        }

        public void Init()
        {
            player1 = new Player(new PointF(400, 400));

            gameOverScreen = new Picture("Images/GameOver.png", new PointF(this.Width / 2, this.Height / 3), 1, 1);
            victoryScreen = new Picture("Images/Victory.png", new PointF(this.Width / 2, this.Height / 3), 1, 1);

            MainForm.enemyList = new List<Soldier>();

           MainForm.bulletList = new List<Bullet>();
           MainForm.wallList = new List<Wall>();
           MainForm.explosionList = new List<Explosion>();

           // Make some enemies
           EnemySoldier e1 = new EnemySoldier(new PointF(650, 100));
           EnemySoldier e2 = new EnemySoldier(new PointF(200, 400));
          // EnemySoldier e3 = new EnemySoldier(new PointF(-100, -200));
          // EnemySoldier e4 = new EnemySoldier(new PointF(50, 40));

           /* The four major walls for our arena. */
           Wall borderTop = new Wall("Green", 0, 0, this.Width, 30);
           Wall borderLeft = new Wall("Green", 0, 30, 30, this.Height - 60);
           Wall borderBottom = new Wall("Green", 30, this.Height - 60, this.Width - 30, 30);
           Wall borderRight = new Wall("Green", this.Width - 30, 30, 30, this.Height - 60);

           Wall wall1 = new Wall("Blue", 150, 250, 300, 30);
           Wall wall2 = new Wall("Orange", 550, 150, 30, 350);
           

            // Set input on player
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(player1.KeyDown);

            this.KeyUp += new System.Windows.Forms.KeyEventHandler(player1.KeyUp);
           
        }

        public void DrawGame(Object sender, PaintEventArgs e)
        {

            onScreenGraphics.Clear(Color.Black);

            player1.Draw(onScreenGraphics);

            foreach (Soldier s in enemyList)
            {
                s.Draw(onScreenGraphics);
            }

            foreach (Explosion ex in explosionList)
            {
                ex.Draw(onScreenGraphics);
            }

            foreach (Bullet b in bulletList)
            {
                b.Draw(onScreenGraphics);
            }

            
            foreach (Wall b in wallList)
            {
                b.Draw(onScreenGraphics);
            }


            if (player1.killed)
            {
                gameOverScreen.Draw(onScreenGraphics);
            }

            if (enemyList.Count == 0)
            {
                victoryScreen.Draw(onScreenGraphics);
            }

            // Finally, draw the buffer.
            windowsGraphics.DrawImage(screen, new Point(0,0));
            

        }

        private void GameTimer_Tick(object sender, EventArgs e)
        {
            player1.Update(GameTimer.Interval);

            

          for(int i=0; i < enemyList.Count; i++)
          {
               enemyList[i].Update(GameTimer.Interval);
          }

            // update game objects
            for (int i = 0; i < bulletList.Count; i++)
            {
                bulletList[i].Update(GameTimer.Interval);
            }

            for (int i = 0; i < explosionList.Count; i++)
            {
                explosionList[i].Update(GameTimer.Interval);
            }

            OnPaint(
                // This is an Event, and needs a PaintEventArgs to
                // describe what should happen during it.
                new PaintEventArgs(
                // The graphics object we draw with.
                    windowsGraphics,
                // The part of the screen to draw (the whole thing!).
                    new Rectangle(0, 0, this.Width, this.Height)));
        }






    }
}