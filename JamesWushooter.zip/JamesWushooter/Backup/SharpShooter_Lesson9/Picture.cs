using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Drawing.Drawing2D;



namespace SharpShooter_ChrisLotton
{
    public class Picture
    {
        public Bitmap bitmap;
        public PointF location;
        public float angle = 0f;
        public PointF offset;

        // The current frame.
        public int frame =0;
        // The total number of frames.
        public int frameCount;
        // The number of "ticks" per frame.
        public int timePerFrame;

        public int animationCounter = 0;

        public Picture(string fileName,PointF location, int frames, int flipTime)
        {
            this.frameCount = frames;
            this.timePerFrame = flipTime;

            bitmap = new Bitmap(fileName);
            this.location = location;
            offset = new PointF(bitmap.Width / 2f, bitmap.Height/frameCount / 2f);

            
        }


        public void Update(int time)
        {
            animationCounter += time;

            if (animationCounter >= this.timePerFrame)
            {
                this.frame++;
                if (this.frame >= this.frameCount)
                {
                    frame = 0;
                }

                animationCounter = 0;
            }                  
        }

        public void Draw(Graphics g)
        {
            // So that our pictures are centred, treat Location as the middle and find the top left corner.
            Point DrawLocation = new Point((int)(location.X - offset.X), (int)(location.Y - offset.Y));
            Matrix m = new Matrix();
            m.RotateAt(-angle, location); // Rotate by the given angle and around the centre.
            g.Transform = m; // Set the drawing transform to this rotation matrix.

           
            g.DrawImage(bitmap, new Rectangle(DrawLocation.X, DrawLocation.Y, bitmap.Width, bitmap.Height/this.frameCount),
                new Rectangle(0, this.frame*bitmap.Height/this.frameCount, bitmap.Width, bitmap.Height/this.frameCount), GraphicsUnit.Pixel);

        }
    }
}
