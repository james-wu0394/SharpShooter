using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Windows.Forms;

namespace SharpShooter_ChrisLotton
{
    public class EnemySoldier:Soldier
    {

        int directionChangeCount = 0;

        int nextDirectionChange = 0;

        public EnemySoldier(PointF location): base("Images/Enemy1.png", location)
        {
            MainForm.enemyList.Add(this);
            isFiring = true;
            moveSpeed = 2;
            walkDirc = 1;

            //Set currentWeapon to a new instance of EnemyPistol and provide a starting location
            this.currentWeapon = new EnemyPistol(this.location);

            Random r = new Random((int)location.X);
            nextDirectionChange = r.Next(500) + 2000;
            
        }

        public override void Update(int time)
        {
            if (this.HP <= 0)
            {
                MainForm.enemyList.Remove(this);
            }
            base.Update(time);

            directionChangeCount += time;

            if (directionChangeCount >= nextDirectionChange)
            {
                Random r = new Random();
                facingAngle = r.Next(360);

                directionChangeCount = 0;

                nextDirectionChange = r.Next(500) + 2000;
            }

            
        }
    }
}
