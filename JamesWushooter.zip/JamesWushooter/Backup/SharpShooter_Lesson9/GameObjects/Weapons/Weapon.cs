using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;

namespace SharpShooter_ChrisLotton
{
    public abstract class Weapon
    {
        public Picture pic;
        public PointF location;

        public float bulletSpeed;
        public int fireDelay;
        public float bulletStartDistance;
        public float facingAngle;
        public int timeSinceLastShot=0;

        public Weapon(string image, PointF location)
        {
            this.pic = new Picture(image, location, 1, 1);
            this.location = location;
        }

        public void Draw(Graphics g)
        {
            pic.angle = facingAngle;
            pic.location.X = location.X;
            pic.location.Y = location.Y;

            pic.Draw(g);
        }

        public void Fire(Soldier personFiring)
        {
            // Just return without doing anything if not enough
            // time has passed since the last shot.
            if (timeSinceLastShot < fireDelay)
            {
                return;
            }

            // Reset the shot timer.
            timeSinceLastShot = 0;

            float xComponent = (float)Math.Cos(facingAngle / 180f * Math.PI);
            float yComponent = -(float)Math.Sin(facingAngle / 180f * Math.PI);

            Bullet bullet = CreateBullet(personFiring);

            bullet.location.X = this.location.X + xComponent * bulletStartDistance;
            bullet.location.Y = this.location.Y + yComponent * bulletStartDistance;

            bullet.velocity.X = xComponent * bulletSpeed;
            bullet.velocity.Y = yComponent * bulletSpeed;

        }

        public void Update(int time)
        {
            timeSinceLastShot += time;
        }

        public abstract Bullet CreateBullet(Soldier personFiring);
    }
}
