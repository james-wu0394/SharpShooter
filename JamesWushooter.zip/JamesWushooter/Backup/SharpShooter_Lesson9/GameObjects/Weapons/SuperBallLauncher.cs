using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;

namespace SharpShooter_ChrisLotton
{
    public class SuperBallLauncher:Weapon
    {
         public SuperBallLauncher(PointF location)
            : base("Images/SuperBallLauncher.png", location)
        {
            this.bulletSpeed = 8f;
            this.bulletStartDistance = 15f;
            this.fireDelay = 1000;
        }

        public override Bullet CreateBullet(Soldier personFiring)
        {
            return new Bullet("Images/SuperBall.png", personFiring, new PointF());
        }
    }
}
