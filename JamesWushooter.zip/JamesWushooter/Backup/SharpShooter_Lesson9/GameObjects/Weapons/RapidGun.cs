using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;

namespace SharpShooter_ChrisLotton
{
   public class RapidGun:Weapon
    {
         public RapidGun(PointF location)
            : base("Images/RapidGun.png", location)
        {
            this.bulletSpeed = 15f;
            this.bulletStartDistance = 10f;
            this.fireDelay = 20;
        }

        public override Bullet CreateBullet(Soldier personFiring)
        {
            return new Bullet("Images/Bullet3.png", personFiring, new PointF());
        }
    }
}
