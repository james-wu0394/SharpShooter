using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Windows.Forms;


namespace SharpShooter_ChrisLotton
{
    public class Soldier
    {

        public Weapon currentWeapon;

        public Picture pic;

        public PointF location;

        public float facingAngle = 0;

        public PointF velocity;

        public int radius;

        public int HP = 5;

        public bool killed = false;

        public bool hitFlicker = false;

        public int hitFlickerCount = 0;

        // The direction we are walking.  1 for forward, -1 for back, 0 for stop.
        public int walkDirc = 0;

        // The direction in which we're turning. +ve for left, -ve for right.
        public float turnDirc = 0;

        public int moveSpeed = 10;

        public bool isFiring = false;

     
     

        public Soldier(String image, PointF location)
        {
            pic = new Picture(image, location, 4, 60);
            velocity = new PointF();
            this.location = location;
            Random r = new Random((int)DateTime.Now.Ticks);
            facingAngle = r.Next(360); // Pick a random direction to start.

            radius = pic.bitmap.Width / 2;
            
        }

        public void UpdateWeapon(int time)
        {
            // Create two floats called xOffset and yOffset used to put the gun in the Soldier's hands.
            //Use sin and cos to fill xOffset and yOffset.
            float xOffset = (float)Math.Cos(this.facingAngle / 180f * Math.PI) * 32f;
            float yOffset = -(float)Math.Sin(this.facingAngle / 180f * Math.PI) * 32f;

            //Set the currentWeapon's X and Y location to the Soldier's hands.
            currentWeapon.location.X = location.X + xOffset;
            currentWeapon.location.Y = location.Y + yOffset;

            //Set the currentWeapon's facingAngle to this soldier's facingAngle.
            currentWeapon.facingAngle = this.facingAngle;

            //Update the currentWeapon.
            currentWeapon.Update(time);
        }

        public void Draw(Graphics g)
        {
            if (this.killed)
            {
                return;
            }

            pic.angle = facingAngle;

            if (!hitFlicker)
            {
                // The image location is our location.
                pic.location.X = location.X;
                pic.location.Y = location.Y;

                pic.Draw(g);

                currentWeapon.Draw(g);
            }
        }

        public void Move()
        {
            location.X += velocity.X;
            location.Y += velocity.Y;

        }

        public void TakeDamage(int damage)
        {
           
            HP -= damage;
            hitFlickerCount = 4;
            
        }


        public virtual void Update(int time)
        {

            if (HP <= 0)
            {
                
                // We're dead.
                killed = true;
                Explosion e = new Explosion(this.location);
                return;
            }

            // Flicker effect. Just turn on and off until counter expired.
            if (hitFlickerCount > 0)
            {
                hitFlickerCount--;
                hitFlicker = !hitFlicker;
            }
            else
            {
                hitFlicker = false;
            }

            // Rotate based on the turning direction.
            facingAngle += ((float)(time)) * turnDirc;


            // Determine forward velocity from angle being faced.
            velocity.X = (float)Math.Cos(facingAngle / 180f * Math.PI) * walkDirc * moveSpeed;
            velocity.Y = -(float)Math.Sin(facingAngle / 180f * Math.PI) * walkDirc * moveSpeed;

            Move();

            if (velocity.X != 0 || velocity.Y != 0)
            {
                pic.Update(time);
            }
            

          

            if (isFiring)
            {
                currentWeapon.Fire(this);
            }

            foreach (Wall w in MainForm.wallList)
            {
                
                PointF touchPoint = new PointF();
                if (this.isTouchingWall(w, ref touchPoint))
                {
                    PushFrom(touchPoint);
                }
            }

            this.UpdateWeapon(time);


        }

      

        public bool isTouchingWall(Wall w, ref PointF touchPoint)
        {

            // First we need the nearest point on the wall, which
            // takes some work, so we have a seperate function for it.
            PointF nearestPoint = w.pointNearestTo(this.location);

            // Now see if the nearestPoint is touching the wall using Pythagorean Theorem
            // Just like in the Touching function in the Bullet class
            float distance = (float)Math.Sqrt(
                (nearestPoint.X - location.X) * (nearestPoint.X - location.X)
                + (nearestPoint.Y - location.Y) * (nearestPoint.Y - location.Y));


            // If the distance is less than the radius, that point is in the circle
            // So set the touchPoint to nearestPoint and return true to indicate that we
            // found overlap.  Else just return false.
            if (distance < this.radius)
            {
                touchPoint = nearestPoint;
                return true;
            }
            else
            {
                return false;
            }

        }

        public void PushFrom(PointF p)
        {
            // Calculate the actualDistance between the points p and this soldiers location, using Pythagorean Theorem.
            float actualDistance = (float)Math.Sqrt((p.X - this.location.X) * (p.X - this.location.X)
                + (p.Y - this.location.Y) * (p.Y - this.location.Y));

            //Just leave this function if the actualDistance is 0 (somehow this solider is on the point p)
            if (actualDistance == 0)
            {
                return;
            }

            //A float called desiredDistance is set to the radius of this soldier plus 1, to push him slightly off the wall.
            float desiredDistance = this.radius + 1;

            // The amount to multiply against the move direction.
            float proportion = desiredDistance / actualDistance;

            // Initialize a new PointF vector called move and set the X and Y coordinates to
            //the distance between this Soldier and p�s X and Y coordinates.  Then adjust its
            //length by multiplying it by the scalar above.
            PointF move = new PointF(this.location.X - p.X, this.location.Y - p.Y);
            move.X *= proportion;
            move.Y *= proportion;

            // Move this object away from p
            this.location.X = p.X + move.X;
            this.location.Y = p.Y + move.Y;
        }

    }
}
