using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.Drawing;
using SharpShooter_ChrisLotton.GameObjects;

namespace SharpShooter_ChrisLotton
{
    public partial class MainForm : Form
    {

        public static Player player1;
        public static List<Soldier> enemyList;
        public static List<Bullet> bulletList;
        public static List<Wall> wallList;
        public static List<Explosion> explosionList;
        public static List<Weapon> weaponList;

        public static Point viewOffset;

        //double buffering
        Graphics windowsGraphics;
        Graphics onScreenGraphics;
        Bitmap screen;

        public Picture gameOverScreen;
        public Picture victoryScreen;

        public static Panel panel;

        HPBar hpbar;


        public MainForm()
        {
            InitializeComponent();

            panel = new System.Windows.Forms.Panel();

            windowsGraphics = this.CreateGraphics();
            screen = new Bitmap(this.Width, this.Height);
            onScreenGraphics = Graphics.FromImage(screen);
           
            // Set our DrawGame method to be called when the window repaints
            this.Paint += new PaintEventHandler(DrawGame);


            //Init();
        }

        public void Init()
        {
            LevelGenerator level = new LevelGenerator();
            level.CreateLevel();
            hpbar = new HPBar();
            gameOverScreen = new Picture("Images/GameOver.png", new PointF(this.Width / 2, this.Height / 3), 1, 1);
            victoryScreen = new Picture("Images/Victory.png", new PointF(this.Width / 2, this.Height / 3), 1, 1);

            // Set input on player
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(player1.KeyDown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(player1.KeyUp);


            this.MouseDown += new System.Windows.Forms.MouseEventHandler(player1.MouseDown);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(player1.MouseUp);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(player1.MouseMove);
        }

        public void createMoreWeapons()
        {
            if (MainForm.weaponList.Count == 0)
            {
                Random rnd = new Random();
                int randomX = rnd.Next(-5, 24);
                int randomY = rnd.Next(-5, 24);
                int randomGun = rnd.Next(1, 4);

                switch (randomGun)
                {
                    case 1:
                        SniperRifle sniper = new SniperRifle(new PointF(randomX * 50 - 400, randomY * 50 - 400));
                        sniper.onGround = true;
                        MainForm.weaponList.Add(sniper);
                        break;

                    case 2:
                        RapidGun rapid = new RapidGun(new PointF(randomX * 50 - 400, randomY * 50 - 400));
                        rapid.onGround = true;
                        MainForm.weaponList.Add(rapid);
                        break;

                    case 3:
                        SuperBallLauncher super = new SuperBallLauncher(new PointF(randomX * 50 - 400, randomY * 50 - 400));
                        super.onGround = true;
                        MainForm.weaponList.Add(super);
                        break;
                }
            }
        }

        public void DrawGame(Object sender, PaintEventArgs e)
        {
            if (!GameTimer.Enabled)
            {
                return;
            }

            onScreenGraphics.Clear(Color.Black);

            player1.Draw(onScreenGraphics);

            foreach (Soldier s in enemyList)
            {
                s.Draw(onScreenGraphics);
            }

            foreach (Explosion ex in explosionList)
            {
                ex.Draw(onScreenGraphics);
            }

            foreach (Bullet b in bulletList)
            {
                b.Draw(onScreenGraphics);
            }
            
            foreach (Wall b in wallList)
            {
                b.Draw(onScreenGraphics);
            }

            foreach (Weapon w in weaponList)
            {
                w.Draw(onScreenGraphics);
            }


            if (player1.killed)
            {
                gameOverScreen.Draw(onScreenGraphics);
            }

            if (enemyList.Count == 0)
            {
                victoryScreen.Draw(onScreenGraphics);
            }

            //Draw HP Bar
            hpbar.Draw(onScreenGraphics);

            // Finally, draw the buffer.
            windowsGraphics.DrawImage(screen, new Point(0,0));
            

        }

        //MAIN LOOP
        private void GameTimer_Tick(object sender, EventArgs e)
        {
            player1.Update(GameTimer.Interval);
            hpbar.Update(GameTimer.Interval);

            //creates more powerups when there are none left
            createMoreWeapons();

          for (int i=0; i < enemyList.Count; i++)
          {
               enemyList[i].Update(GameTimer.Interval);
          }

            // update game objects
            for (int i = 0; i < bulletList.Count; i++)
            {
                bulletList[i].Update(GameTimer.Interval);
            }

            for (int i = 0; i < explosionList.Count; i++)
            {
                explosionList[i].Update(GameTimer.Interval);
            }

            for(int i = 0; i < weaponList.Count; i++)
            {
                weaponList[i].Update(GameTimer.Interval);
            }

            viewOffset.X = (int)player1.location.X - this.Width / 2;
            viewOffset.Y = (int)player1.location.Y - this.Width / 2;

            OnPaint(
                // This is an Event, and needs a PaintEventArgs to
                // describe what should happen during it.
                new PaintEventArgs(
                // The graphics object we draw with.
                    windowsGraphics,
                // The part of the screen to draw (the whole thing!).
                    new Rectangle(0, 0, this.Width, this.Height)));
        }




        private void MainForm_Load(object sender, EventArgs e)
        {

        }

        private void resetToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            Init();

        }

        private void optionsToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void playLabel_Click(object sender, EventArgs e)
        {
            Init();
            GameTimer.Enabled = true;
            Title.Hide();
            playLabel.Hide();
        }

        private void Title_Click(object sender, EventArgs e)
        {

        }
    }
}