﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;

namespace SharpShooter_ChrisLotton.GameObjects
{
    public class EnemySoldier2 : Soldier
    {

        int directionChangeCount = 0;

        //custom turning for enemies
        public bool isTurning = false;
        public float tempFacingAngle = 0;

        int nextDirectionChange = 0;

        public EnemySoldier2(PointF location) : base("Images/Enemy2.png", location)
        {
            MainForm.enemyList.Add(this);
            isFiring = true;
            walkDirc = 0;
            turnDirc = 1;

            HP = 150;

            //Set currentWeapon to a new instance of EnemyPistol and provide a starting location
            this.currentWeapon = new RapidGun(this.location);

            Random r = new Random((int)location.X);
            nextDirectionChange = r.Next(500) + 2000;
        }

        public override void Update(int time)
        {
            if (this.HP <= 0)
            {
                MainForm.enemyList.Remove(this);
            }
            base.Update(time);

            directionChangeCount += time;
        }
    }
}
