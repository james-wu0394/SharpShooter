﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;

namespace SharpShooter_ChrisLotton.GameObjects
{
    class HPBar
    {
        //members
        Rectangle maxHealth;
        Rectangle currentHealth;
        float hpRate;

        public HPBar()
        {
            hpRate = ((float)MainForm.player1.HP / (float)MainForm.player1.maxHP);
            maxHealth = new Rectangle(20,50,500,30);
            
            currentHealth = new Rectangle(20, 50, (int)(hpRate*500), 30);
        }

        public void Draw(Graphics g)
        {

            g.FillRectangle(new SolidBrush(Color.WhiteSmoke), maxHealth);
            g.FillRectangle(new SolidBrush(Color.Red), currentHealth);
            g.DrawRectangle(new Pen(Color.WhiteSmoke),maxHealth);
            g.DrawRectangle(new Pen(Color.Red), maxHealth);

            //create font and brush
            Font drawFont = new Font("Arial", 16);
            SolidBrush drawBrush = new SolidBrush(Color.Black);
            //draws the health value on hp bar
            g.DrawString(MainForm.player1.HP.ToString()+"/"+ MainForm.player1.maxHP.ToString(), drawFont, drawBrush, 35, 55);            
        }

        public void Update(int time)
        {
            hpRate = ((float)MainForm.player1.HP / (float)MainForm.player1.maxHP);
            maxHealth = new Rectangle(20, 50, 500, 30);
            currentHealth = new Rectangle(20, 50, (int)(hpRate * 500), 30);
        }
    }
}
