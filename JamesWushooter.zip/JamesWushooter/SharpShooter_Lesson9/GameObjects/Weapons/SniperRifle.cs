using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;

namespace SharpShooter_ChrisLotton
{
    public class SniperRifle:Weapon
    {
         public SniperRifle(PointF location) : base("Images/SniperRifle.png", location)
        {
            this.bulletSpeed = 30f;
            this.bulletStartDistance = 10f;
            this.fireDelay = 2000;

            damage = 100;
            life = 5.0f;
        }

        public override Bullet CreateBullet(Soldier personFiring)
        {
            return new Bullet("Images/SniperBullet.png", personFiring, new PointF());
        }
    }
}
