using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;

namespace SharpShooter_ChrisLotton
{
    public class EnemyPistol:Weapon
    {
        public EnemyPistol(PointF location)
            : base("Images/Pistol.png", location)
        {
            this.bulletSpeed = 15f;
            this.bulletStartDistance = 10f;
            this.fireDelay = 600;

            damage = 25;
            life = 3.0f;
        }

        public override Bullet CreateBullet(Soldier personFiring)
        {
            return new Bullet("Images/Bullet1.png", personFiring, new PointF());
        }
    }
}
