﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;

namespace SharpShooter_ChrisLotton.GameObjects
{
    class EnemySoldier3 : Soldier
    {
        int directionChangeCount = 0;
        //custom turning for enemies
        public bool isTurning = false;
        public float tempFacingAngle = 0;

        int nextDirectionChange = 0;

        public EnemySoldier3(PointF location): base("Images/Enemy3.png", location)
        {
            MainForm.enemyList.Add(this);
            isFiring = true;
            moveSpeed = 2;
            walkDirc = 1;
            HP = 300;

            //Set currentWeapon to a new instance of EnemyPistol and provide a starting location
            this.currentWeapon = new SuperBallLauncher(this.location);

            Random r = new Random((int)location.X);
            nextDirectionChange = r.Next(500) + 2000;
        }

        public override void Update(int time)
        {
            if (this.HP <= 0)
            {
                MainForm.enemyList.Remove(this);
            }
            base.Update(time);

            directionChangeCount += time;

            if (directionChangeCount >= nextDirectionChange)
            {
                Random r = new Random();
                tempFacingAngle = r.Next(360);

                directionChangeCount = 0;
                nextDirectionChange = r.Next(500) + 2000;

                isTurning = true;
            }

            if (isTurning)
            {
                if (facingAngle < tempFacingAngle - 5)
                {
                    turnDirc = 0.5f;
                }

                else if (facingAngle > tempFacingAngle + 5)
                {
                    turnDirc = -0.5f;
                }

                else if ((facingAngle > (tempFacingAngle - 5) || facingAngle < (tempFacingAngle) || (facingAngle < (tempFacingAngle + 5) || facingAngle > tempFacingAngle)))
                {
                    turnDirc = 0;
                    isTurning = false;
                    facingAngle = tempFacingAngle;
                }
            }
        }
    }
}



