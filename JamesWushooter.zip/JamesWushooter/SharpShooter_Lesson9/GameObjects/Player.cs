using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Windows.Forms;

namespace SharpShooter_ChrisLotton
{
    public class Player:Soldier
    {
        public List<Weapon> playerWeaponList;
        int weaponHolder;

        public Player(PointF location):base("Images/Player.png",location)
        {
            this.currentWeapon = new EnemyPistol(this.location);
            playerWeaponList = new List<Weapon>();

            playerWeaponList.Add(currentWeapon);
            weaponHolder = 0;  //temp var for index of list
            HP = 200;
            maxHP = 200;
        }
        
        public void KeyDown(Object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.A)
            {
                strafDirc = 1;
            }

            if (e.KeyCode == Keys.D)
            {
                strafDirc = -1;
            }

            if (e.KeyCode == Keys.W)
            {
                walkDirc = 1;
            }
            if (e.KeyCode == Keys.S)
            {
                walkDirc = -1;
            }

            if (e.KeyCode == Keys.Space)
            {

            }

            //swaps weapons
            if (e.KeyCode == Keys.E)
            {
                if (weaponHolder == (playerWeaponList.Count - 1))
                {
                    //resets the index back to 0
                    weaponHolder = 0;
                }
                else
                {
                    weaponHolder += 1;
                }              
                //System.Diagnostics.Debug.Print("List: "+ playerWeaponList.Count+"Hold: "+ weaponHolder.ToString());               
                currentWeapon = playerWeaponList[weaponHolder];
            }
        }

        public void KeyUp(Object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.A)
            {
                strafDirc = 0;
            }

            if (e.KeyCode == Keys.D)
            {
                strafDirc = 0;
            }

            if (e.KeyCode == Keys.W)
            {
                walkDirc = 0;
            }

            if (e.KeyCode == Keys.S)
            {
                walkDirc = 0;
            }

            if (e.KeyCode == Keys.Space)
            {

            }          
        }

        public void MouseDown(Object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                isFiring = true;
            }
        }

        public void MouseUp(Object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                isFiring = false;
            }
        }

        public void MouseMove(Object sender, MouseEventArgs e)
        {
            var relativePoint = MainForm.panel.PointToClient(Cursor.Position);  //find x/y coords of mouse relative to window
            double xDiff = relativePoint.X - MainForm.ActiveForm.Width / 2;  //this is the middle of the screen
            double yDiff = relativePoint.Y - MainForm.ActiveForm.Height / 2;  //this is the middle of the screen

            var angle = Math.Atan2(-yDiff, xDiff);
            angle = angle * 180f / Math.PI;

            facingAngle = (float)angle;
        } 
        
    }
}
