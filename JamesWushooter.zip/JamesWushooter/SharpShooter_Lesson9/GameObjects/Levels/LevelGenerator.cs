﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;
using SharpShooter_ChrisLotton.GameObjects.Levels;

namespace SharpShooter_ChrisLotton.GameObjects
{
    public class LevelGenerator : LevelBase
    {

        public override void CreateEnemies()
        {
            // Make some enemies
            EnemySoldier e1 = new EnemySoldier(new PointF(650, 100));
            EnemySoldier e2 = new EnemySoldier(new PointF(200, 400));
            EnemySoldier e3 = new EnemySoldier(new PointF(-100, -200));
            EnemySoldier e4 = new EnemySoldier(new PointF(50, 40));

            EnemySoldier2 e5 = new EnemySoldier2(new PointF(600, 600));
            EnemySoldier2 e6 = new EnemySoldier2(new PointF(-600, 600));
            EnemySoldier2 e7 = new EnemySoldier2(new PointF(600, -600));
            EnemySoldier2 e8 = new EnemySoldier2(new PointF(-600, -600));

            EnemySoldier3 e9 = new EnemySoldier3(new PointF(700, -700));

        }

        public override void CreateWalls()
        {
            //all this creates a random maze
            int countX = 14;
            int countY = 14;

            int tempWidth;
            int tempHeight;

            Random rnd = new Random();
            int rndHolder;
            for (int i = 0; i < countX; i++)
            {

                for (int j = 0; j < countY; j++)
                {
                    rndHolder = rnd.Next(0, 4);
                    if (rndHolder == 1)
                    {
                        tempHeight = 20;
                        tempWidth = 120;
                        MainForm.wallList.Add(new Wall("Blue", -800 + (i * 120), -800 + (j * 120), tempWidth, tempHeight));
                    }
                    else if (rndHolder == 2)
                    {
                        tempHeight = 120;
                        tempWidth = 20;
                        MainForm.wallList.Add(new Wall("Blue", -800 + (i * 120), -800 + (j * 120), tempWidth, tempHeight));
                    }
                }
            }
        }

        public override void createWeapons()
        {
            SniperRifle sr = new SniperRifle(new PointF(-350, -750));
            sr.onGround = true;
            MainForm.weaponList.Add(sr);

            RapidGun rg = new RapidGun(new PointF(-500, 100));
            rg.onGround = true;
            MainForm.weaponList.Add(rg);

            SuperBallLauncher sbl = new SuperBallLauncher(new PointF(500, 350));
            sbl.onGround = true;
            MainForm.weaponList.Add(sbl);
        }

        public override void CreateLevel()
        {
            //spawn player
            MainForm.player1 = new Player(new PointF(0, 400));

            initialiseLists();
            createWeapons();
            CreateWalls();
            createBorders(-800, -800, 1600, 1600);
            CreateEnemies();
        }
    }
}
