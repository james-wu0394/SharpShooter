﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;

namespace SharpShooter_ChrisLotton.GameObjects.Levels
{
    public abstract class LevelBase
    {

        public static void initialiseLists()
        {
            MainForm.enemyList = new List<Soldier>();
            MainForm.bulletList = new List<Bullet>();
            MainForm.wallList = new List<Wall>();
            MainForm.explosionList = new List<Explosion>();
            MainForm.weaponList = new List<Weapon>();
        }

        public static void createBorders(int topX, int topY, int width, int height)
        {
            /* The four major walls for our arena. */
            Wall borderTop = new Wall("Green", topX - 80, topY - 80, width + 80, 80);
            Wall borderLeft = new Wall("Green", topX - 80, topY, 80, height + 80);
            Wall borderBottom = new Wall("Green", topX, topY + height, width + 80, 80);
            Wall borderRight = new Wall("Green", topX + width, topY - 80, 80, width + 80);
        }

        public abstract void CreateWalls();

        public abstract void CreateEnemies();

        public abstract void CreateLevel();

        public abstract void createWeapons();

    }
}

