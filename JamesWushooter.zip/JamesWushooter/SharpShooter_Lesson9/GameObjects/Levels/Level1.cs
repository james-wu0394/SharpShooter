﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;

namespace SharpShooter_ChrisLotton.GameObjects
{
    public class Level
    {

        public static void initialiseLists()
        {
            MainForm.enemyList = new List<Soldier>();
            MainForm.bulletList = new List<Bullet>();
            MainForm.wallList = new List<Wall>();
            MainForm.explosionList = new List<Explosion>();

    }

        public static void createBorders(int topX, int topY, int width, int height)
        {
            /* The four major walls for our arena. */
            Wall borderTop = new Wall("Green", topX - 80, topY - 80, width + 80, 80);
            Wall borderLeft = new Wall("Green", topX - 80, topY, 80, height + 80);
            Wall borderBottom = new Wall("Green", topX, topY + height, width + 80, 80);
            Wall borderRight = new Wall("Green", topX + width, topY - 80, 80, width + 80);
        }

        public static void createWalls()
        {
            //spawn
            Wall wall1 = new Wall("Orange", 150, 250, 290, 20);

            Wall wall2a = new Wall("Orange", 550, 150, 30, 350);
            Wall wall2b = new Wall("Orange", 250, 550, 250, 30);

            Wall wall3 = new Wall("Orange", 400, -200, 40, 500);
            Wall wall4 = new Wall("Orange", 100, 0, 50, 300);
            Wall wall5 = new Wall("Orange", 200, 400, 60, 300);




            Wall wall7 = new Wall("Blue", -200, 300, 50, 440);
        }


        public static void createEnemies()
        {
            // Make some enemies
            EnemySoldier e1 = new EnemySoldier(new PointF(650, 100));
            EnemySoldier e2 = new EnemySoldier(new PointF(200, 400));
            EnemySoldier e3 = new EnemySoldier(new PointF(-100, -200));
            EnemySoldier e4 = new EnemySoldier(new PointF(50, 40));

            EnemySoldier2 e5 = new EnemySoldier2(new PointF(600, 800));
        }


        public static void createLevel()
        {
            MainForm.player1 = new Player(new PointF(400, 400));

            initialiseLists();
            createBorders(-800, -800, 1600, 1600);
            createWalls();
            createEnemies();
        }
    }
}
